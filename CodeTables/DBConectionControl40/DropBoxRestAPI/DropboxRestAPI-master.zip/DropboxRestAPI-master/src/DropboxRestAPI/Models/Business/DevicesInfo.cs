/*
 * The MIT License (MIT)
 * 
 * Copyright (c) 2014 Itay Sagui
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */


namespace DropboxRestAPI.Models.Business
{
    public class DevicesInfo
    {
        public string start_date { get; set; }
        public long?[] total_devices_1_day { get; set; }
        public long?[] total_devices_7_day { get; set; }
        public long?[] total_devices_28_day { get; set; }
        public long?[] ios_devices_1_day { get; set; }
        public long?[] ios_devices_7_day { get; set; }
        public long?[] ios_devices_28_day { get; set; }
        public long?[] android_devices_1_day { get; set; }
        public long?[] android_devices_7_day { get; set; }
        public long?[] android_devices_28_day { get; set; }
        public long?[] macos_devices_1_day { get; set; }
        public long?[] macos_devices_7_day { get; set; }
        public long?[] macos_devices_28_day { get; set; }
        public long?[] windows_devices_1_day { get; set; }
        public long?[] windows_devices_7_day { get; set; }
        public long?[] windows_devices_28_day { get; set; }
        public long?[] linux_devices_1_day { get; set; }
        public long?[] linux_devices_7_day { get; set; }
        public long?[] linux_devices_28_day { get; set; }
        public long?[] other_devices_1_day { get; set; }
        public long?[] other_devices_7_day { get; set; }
        public long?[] other_devices_28_day { get; set; }
    }
}