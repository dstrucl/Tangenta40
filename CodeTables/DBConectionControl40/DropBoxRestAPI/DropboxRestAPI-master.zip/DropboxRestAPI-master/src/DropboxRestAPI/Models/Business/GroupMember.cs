namespace DropboxRestAPI.Models.Business
{
    public class GroupMember
    {
        public MemberProfile profile { get; set; }
        public string access_type { get; set; }
    }
}