﻿
namespace DropNet.Tests
{
    public static class TestVariables
    {
        //Insert yo stuff here to run the tests
        public static string ApiKey = "APIKEY";
        public static string ApiSecret = "APISECRET";

        public static string ApiKey_Sandbox = "SANDBOXKEY";
        public static string ApiSecret_Sandbox = "SANDBOXSECRET";

        public static string Email = "EMAIL";
        public static string Password = "PASSWORD";

        public static string Token = "TOKEN";
        public static string Secret = "SECRET";

        public static string Token_Sandbox = "SANDBOXTOKEN";
        public static string Secret_Sandbox = "SANDBOXSECRET";
    }
}
